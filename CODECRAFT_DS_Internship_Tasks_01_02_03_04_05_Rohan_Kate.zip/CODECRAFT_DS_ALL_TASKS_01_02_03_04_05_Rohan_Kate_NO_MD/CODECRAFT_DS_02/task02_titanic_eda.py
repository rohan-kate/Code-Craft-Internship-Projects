import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv("titanic_cleaned.csv")
print(df.info())
print(df.describe(include="all"))

df["Survived"].value_counts().sort_index().plot(kind="bar")
plt.title("Survival Distribution")
plt.show()

pd.crosstab(df["Sex"], df["Survived"]).plot(kind="bar")
plt.title("Survival by Gender")
plt.show()

pd.crosstab(df["Pclass"], df["Survived"]).plot(kind="bar")
plt.title("Survival by Passenger Class")
plt.show()
