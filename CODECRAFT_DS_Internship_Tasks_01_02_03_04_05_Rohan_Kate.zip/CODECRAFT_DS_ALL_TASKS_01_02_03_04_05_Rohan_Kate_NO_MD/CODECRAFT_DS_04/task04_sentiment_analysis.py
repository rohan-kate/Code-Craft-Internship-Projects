import pandas as pd
import re
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report

df = pd.read_csv("cleaned_sample_5000.csv")
df["text"] = df["text"].fillna("").astype(str)

X_train, X_test, y_train, y_test = train_test_split(
    df["text"], df["sentiment"], test_size=0.2,
    random_state=42, stratify=df["sentiment"]
)

vectorizer = TfidfVectorizer(max_features=30000, ngram_range=(1,2))
X_train_vec = vectorizer.fit_transform(X_train)
X_test_vec = vectorizer.transform(X_test)

model = LogisticRegression(max_iter=500, class_weight="balanced")
model.fit(X_train_vec, y_train)

print(classification_report(y_test, model.predict(X_test_vec)))
