# CodeCraft Task 05 — Traffic Accident EDA
# This script reproduces the core analysis from the supplied source notebook.
# Place US_Accidents_Dec21_updated.csv beside this script or update DATA_PATH.

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

DATA_PATH = "US_Accidents_Dec21_updated.csv"
df = pd.read_csv(DATA_PATH)

print("Original shape:", df.shape)
print("\nMissing values (%):")
print((df.isna().mean()*100).sort_values(ascending=False).head(15))

# Weather-related cleaning from the supplied notebook
weather_cols = [
    "Temperature(F)", "Wind_Chill(F)", "Humidity(%)",
    "Pressure(in)", "Visibility(mi)", "Wind_Direction",
    "Wind_Speed(mph)", "Weather_Condition"
]
df = df.dropna(subset=weather_cols)
df = df.dropna(subset=[
    "City", "Sunrise_Sunset", "Civil_Twilight",
    "Nautical_Twilight", "Astronomical_Twilight"
])

print("After weather/time-related cleaning:", df.shape)

# Top cities
print("\nTop 10 cities:")
print(df["City"].value_counts().head(10))

# Severity
print("\nSeverity:")
print(df["Severity"].value_counts().sort_index())

# Time
df["Start_Time"] = pd.to_datetime(df["Start_Time"], errors="coerce")
print("\nAccidents by hour:")
print(df["Start_Time"].dt.hour.value_counts().sort_index())

# Weather
print("\nTop weather conditions:")
print(df["Weather_Condition"].value_counts().head(20))

# Basic plots
df["City"].value_counts().head(10).sort_values().plot(kind="barh", title="Top 10 Cities by Accidents")
plt.xlabel("Accidents")
plt.tight_layout()
plt.show()

df["Severity"].value_counts().sort_index().plot(kind="bar", title="Accidents by Severity")
plt.xlabel("Severity")
plt.ylabel("Accidents")
plt.tight_layout()
plt.show()

sns.histplot(df["Start_Time"].dt.hour, bins=24)
plt.title("Accidents Count by Time of Day")
plt.xlabel("Hour")
plt.show()
