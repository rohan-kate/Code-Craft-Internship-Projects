import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv("cleaned_population_latest_year.csv")
top10 = df.sort_values("Population", ascending=False).head(10)

plt.barh(top10["Country Name"][::-1], top10["Population"][::-1])
plt.title("Top 10 Countries by Total Population")
plt.xlabel("Population")
plt.show()

plt.hist(df["Population"], bins=30)
plt.title("Distribution of Country Populations")
plt.xlabel("Population")
plt.ylabel("Number of Countries")
plt.show()
