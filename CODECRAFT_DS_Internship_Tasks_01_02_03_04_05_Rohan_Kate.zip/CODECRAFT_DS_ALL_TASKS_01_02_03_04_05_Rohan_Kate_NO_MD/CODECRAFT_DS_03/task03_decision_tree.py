import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder
from sklearn.pipeline import Pipeline
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score, classification_report

df = pd.read_csv("data/bank-full.csv", sep=";")
X = df.drop(columns=["y"])
y = df["y"].map({"no": 0, "yes": 1})

cat = X.select_dtypes(include="object").columns
num = X.select_dtypes(exclude="object").columns

pre = ColumnTransformer([
    ("cat", OneHotEncoder(handle_unknown="ignore"), cat),
    ("num", "passthrough", num)
])

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.20, random_state=42, stratify=y
)

model = Pipeline([
    ("pre", pre),
    ("clf", DecisionTreeClassifier(
        max_depth=6, min_samples_leaf=20,
        class_weight="balanced", random_state=42
    ))
])

model.fit(X_train, y_train)
pred = model.predict(X_test)
print("Accuracy:", accuracy_score(y_test, pred))
print(classification_report(y_test, pred))
